plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.evsohbet"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.evsohbet"
        minSdk = 29          // Android 10 ve üstü
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    // Sabit imza anahtarı: yeni sürümler eskisinin üzerine kurulabilsin
    signingConfigs {
        create("birds") {
            storeFile = file("birds.jks")
            storePassword = "birds-ev"
            keyAlias = "birds"
            keyPassword = "birds-ev"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("birds")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("birds")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
