package com.evsohbet

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateUtils
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------- Renkler (gece teması) ----------------

val Night = Color(0xFF0E1117)
val Panel = Color(0xFF161B22)
val Bubble = Color(0xFF1C222B)
val MineBubble = Color(0xFF2A3550)
val Gold = Color(0xFFFFC14D)
val OnGold = Color(0xFF2A1D00)
val TextMain = Color(0xFFE6E8EB)
val TextMuted = Color(0xFF8B949E)
val Line = Color(0xFF222932)
val OnlineGreen = Color(0xFF3FB950)
val AvatarColors = listOf(
    Color(0xFFF78166), Color(0xFF7EE787), Color(0xFF79C0FF),
    Color(0xFFD2A8FF), Color(0xFFFFA657), Color(0xFFFF7B9C),
)

val BirdsColors = darkColorScheme(
    primary = Gold, onPrimary = OnGold,
    primaryContainer = MineBubble, onPrimaryContainer = Color(0xFFEAF0FF),
    secondary = Gold, onSecondary = OnGold,
    background = Night, onBackground = TextMain,
    surface = Night, onSurface = TextMain,
    surfaceVariant = Bubble, onSurfaceVariant = TextMuted,
    surfaceContainer = Panel, surfaceContainerHigh = Bubble, surfaceContainerHighest = Bubble,
    outline = Color(0xFF3A424D), outlineVariant = Line,
    error = Color(0xFFFF7B72),
)

private val TR = Locale.forLanguageTag("tr")

class MainActivity : ComponentActivity() {
    private val openChat = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        Repo.init(applicationContext)
        openChat.value = intent?.getStringExtra(EXTRA_CHAT)
        setContent {
            MaterialTheme(colorScheme = BirdsColors) {
                Surface(Modifier.fillMaxSize(), color = Night) { App(openChat) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_CHAT)?.let { openChat.value = it }
    }

    override fun onResume() {
        super.onResume()
        Repo.visible = true
        openChat.value?.let { Repo.clearUnread(it) }
    }

    override fun onPause() {
        Repo.visible = false
        super.onPause()
    }
}

@Composable
fun App(openChat: MutableState<String?>) {
    val name by Repo.myName.collectAsState()
    if (name == null) {
        NameScreen()
        return
    }
    val ctx = LocalContext.current
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, NetService::class.java))
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val chat = openChat.value
    LaunchedEffect(chat) {
        Repo.activeChat = chat
        chat?.let { Repo.clearUnread(it) }
    }
    if (chat == null) {
        ChatList(onOpen = { openChat.value = it })
    } else {
        BackHandler { openChat.value = null }
        ChatScreen(chat, onBack = { openChat.value = null })
    }
}

@Composable
fun rememberNow(): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

// ---------------- Ortak parçalar ----------------

@Composable
fun BirdLogo(size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Panel),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painterResource(R.drawable.ic_launcher_foreground), contentDescription = null,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

fun avatarColor(id: String) = AvatarColors[(id.hashCode() and 0x7fffffff) % AvatarColors.size]

@Composable
fun Avatar(name: String, id: String, size: Dp = 48.dp, online: Boolean = false) {
    val c = avatarColor(id)
    Box(Modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(c.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase(TR), color = c,
                fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.4f).sp,
            )
        }
        if (online) OnlineDot(Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
fun OnlineDot(modifier: Modifier = Modifier) {
    Box(
        modifier.size(14.dp).clip(CircleShape).background(Night).padding(2.5.dp)
            .clip(CircleShape).background(OnlineGreen)
    )
}

fun shortTime(t: Long): String =
    if (DateUtils.isToday(t)) SimpleDateFormat("HH:mm", TR).format(Date(t))
    else SimpleDateFormat("d MMM", TR).format(Date(t))

// ---------------- İsim ----------------

@Composable
fun NameScreen() {
    var n by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BirdLogo(112.dp)
        Spacer(Modifier.height(24.dp))
        Text("Birds'e hoş geldin", fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Yuvadakiler seni hangi isimle görsün?",
            color = TextMuted, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = n, onValueChange = { n = it }, singleLine = true,
            placeholder = { Text("Adın") }, shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Line, focusedBorderColor = Gold,
                unfocusedContainerColor = Panel, focusedContainerColor = Panel,
            ),
        )
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { if (n.isNotBlank()) Repo.setName(n.trim()) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
        ) { Text("Başla", fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
    }
}

@Composable
fun NameDialog(onDismiss: () -> Unit) {
    var n by remember { mutableStateOf(Repo.myName.value ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Adın") },
        text = {
            OutlinedTextField(
                value = n, onValueChange = { n = it }, singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Gold),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (n.isNotBlank()) Repo.setName(n.trim()); onDismiss() }) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç", color = TextMuted) } },
    )
}

// ---------------- Sohbet listesi ----------------

@Composable
fun ChatList(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val peers by Repo.peers.collectAsState()
    val msgs by Repo.messages.collectAsState()
    val unread by Repo.unread.collectAsState()
    val myName by Repo.myName.collectAsState()
    val now = rememberNow()
    val batteryOk = remember(now) { isIgnoringBattery(ctx) }
    var editName by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Night,
        topBar = {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BirdLogo(38.dp)
                Spacer(Modifier.width(12.dp))
                Text("Birds", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = { editName = true }) {
                    Avatar(myName ?: "?", Repo.myId, size = 34.dp)
                }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (!batteryOk) item(key = "battery") {
                Surface(
                    color = Panel, shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
                ) {
                    Column(Modifier.padding(start = 16.dp, top = 14.dp, end = 8.dp, bottom = 4.dp)) {
                        Text("Ekran kapalıyken de mesaj al", fontWeight = FontWeight.Medium)
                        Text(
                            "Pil kısıtlamasını kaldırırsan Birds arka planda uyumaz.",
                            color = TextMuted, fontSize = 13.sp,
                        )
                        TextButton(onClick = { requestBattery(ctx) }, modifier = Modifier.align(Alignment.End)) {
                            Text("Kısıtlamayı kaldır")
                        }
                    }
                }
            }

            val onlineCount = peers.values.count { it.isOnline(now) }
            item(key = GROUP) {
                ChatRow(
                    avatar = {
                        Box(Modifier.size(48.dp)) {
                            BirdLogo(48.dp)
                            if (onlineCount > 0) OnlineDot(Modifier.align(Alignment.BottomEnd))
                        }
                    },
                    title = "Yuva",
                    preview = lastPreview(msgs, GROUP)
                        ?: if (onlineCount == 0) "Henüz kimse çevrimiçi değil" else "$onlineCount kişi çevrimiçi",
                    time = msgs.lastOrNull { it.chat == GROUP }?.time,
                    unread = unread[GROUP] ?: 0,
                    onClick = { onOpen(GROUP) },
                )
            }

            val sorted = peers.values.sortedWith(
                compareByDescending<Peer> { it.isOnline(now) }.thenBy { it.name.lowercase(TR) }
            )
            if (sorted.isNotEmpty()) item(key = "hdr") {
                Text(
                    "KİŞİLER", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 4.dp),
                )
            }
            items(sorted, key = { it.id }) { p ->
                val on = p.isOnline(now)
                ChatRow(
                    avatar = { Avatar(p.name, p.id, online = on) },
                    title = p.name,
                    preview = lastPreview(msgs, p.id) ?: if (on) "çevrimiçi" else "çevrimdışı",
                    time = msgs.lastOrNull { it.chat == p.id }?.time,
                    unread = unread[p.id] ?: 0,
                    onClick = { onOpen(p.id) },
                )
            }

            if (peers.isEmpty()) item(key = "empty") {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Yuva şimdilik sessiz", fontWeight = FontWeight.Medium, fontSize = 17.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Diğer telefonlarda da Birds'ü aç. Aynı Wi-Fi'dayken birbirinizi burada göreceksiniz.",
                        color = TextMuted, textAlign = TextAlign.Center, fontSize = 14.sp,
                    )
                }
            }
        }
    }
    if (editName) NameDialog(onDismiss = { editName = false })
}

fun lastPreview(msgs: List<Msg>, chat: String): String? =
    msgs.lastOrNull { it.chat == chat }?.let {
        val who = when {
            it.mine -> "Sen: "
            chat == GROUP -> "${it.fromName}: "
            else -> ""
        }
        who + (it.text ?: if (it.mime?.startsWith("image/") == true) "Fotoğraf" else "Dosya: ${it.fileName}")
    }

@Composable
fun ChatRow(
    avatar: @Composable () -> Unit,
    title: String, preview: String, time: Long?, unread: Int, onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        avatar()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(
                preview, color = if (unread > 0) TextMain else TextMuted, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            if (time != null) Text(shortTime(time), color = if (unread > 0) Gold else TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            if (unread > 0) {
                Box(
                    Modifier.clip(CircleShape).background(Gold).padding(horizontal = 7.dp, vertical = 1.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("$unread", color = OnGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            } else Spacer(Modifier.height(18.dp))
        }
    }
}

// ---------------- Sohbet ekranı ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(chat: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val all by Repo.messages.collectAsState()
    val peers by Repo.peers.collectAsState()
    val now = rememberNow()
    val msgs = remember(all, chat) { all.filter { it.chat == chat } }
    val peer = peers[chat]
    val title = if (chat == GROUP) "Yuva" else peer?.name ?: "?"
    val onlineCount = peers.values.count { it.isOnline(now) }
    val subtitle = when {
        chat == GROUP -> if (onlineCount == 0) "kimse çevrimiçi değil" else "$onlineCount kişi çevrimiçi"
        peer?.isOnline(now) == true -> "çevrimiçi"
        else -> "çevrimdışı"
    }
    var text by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            Net.sendFile(ctx.applicationContext, chat, u)
        }
    }

    Scaffold(
        containerColor = Night,
        topBar = {
            Column {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Night),
                    navigationIcon = {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri") }
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (chat == GROUP) BirdLogo(38.dp) else Avatar(title, chat, size = 38.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    subtitle, fontSize = 12.sp,
                                    color = if (subtitle == "çevrimiçi" || (chat == GROUP && onlineCount > 0)) OnlineGreen else TextMuted,
                                )
                            }
                        }
                    },
                )
                HorizontalDivider(color = Line, thickness = 0.5.dp)
            }
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().imePadding()
                    .padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 10.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Surface(color = Panel, shape = RoundedCornerShape(26.dp), modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                            Icon(painterResource(R.drawable.ic_attach), contentDescription = "Dosya ekle", tint = TextMuted)
                        }
                        TextField(
                            value = text, onValueChange = { text = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Mesaj", color = TextMuted) },
                            maxLines = 5,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                cursorColor = Gold,
                            ),
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(Gold).clickable {
                        val t = text.trim()
                        if (t.isNotEmpty()) {
                            Net.sendText(chat, t)
                            text = ""
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Gönder", tint = OnGold)
                }
            }
        },
    ) { pad ->
        if (msgs.isEmpty()) {
            Column(
                Modifier.padding(pad).fillMaxSize().padding(40.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                BirdLogo(72.dp)
                Spacer(Modifier.height(16.dp))
                Text("İlk cıvıltıyı sen gönder", color = TextMuted)
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
                itemsIndexed(msgs, key = { _, m -> m.id + m.mine }) { i, m ->
                    val prev = msgs.getOrNull(i - 1)
                    val newDay = prev == null || !sameDay(prev.time, m.time)
                    if (newDay) DayChip(m.time)
                    val firstOfRun = newDay || prev == null || prev.mine != m.mine || prev.fromId != m.fromId
                    MessageBubble(m, showSender = chat == GROUP && !m.mine && firstOfRun, topGap = firstOfRun)
                }
            }
        }
    }
}

fun sameDay(a: Long, b: Long): Boolean {
    val f = SimpleDateFormat("yyyyMMdd", TR)
    return f.format(Date(a)) == f.format(Date(b))
}

@Composable
fun DayChip(t: Long) {
    val label = when {
        DateUtils.isToday(t) -> "Bugün"
        DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Dün"
        else -> SimpleDateFormat("d MMMM yyyy", TR).format(Date(t))
    }
    Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(
            label, color = TextMuted, fontSize = 12.sp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Panel)
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun MessageBubble(m: Msg, showSender: Boolean, topGap: Boolean) {
    val ctx = LocalContext.current
    val shape = if (m.mine) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
    else RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    val bg = if (m.mine) MineBubble else Bubble
    Row(
        Modifier.fillMaxWidth().padding(top = if (topGap) 8.dp else 2.dp),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            Modifier
                .widthIn(max = 290.dp)
                .clip(shape)
                .background(bg)
                .clickable(enabled = m.fileUri != null || m.status == "failed") {
                    if (m.status == "failed") Net.retry(ctx.applicationContext, m) else openFile(ctx, m)
                }
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            if (showSender) {
                Text(m.fromName, color = avatarColor(m.fromId), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
            }
            if (m.fileName != null) {
                val isImage = m.mime?.startsWith("image/") == true && m.fileUri != null
                if (isImage) Thumb(m.fileUri!!)
                if (!isImage || m.fileUri == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Night.copy(alpha = 0.5f)),
                            contentAlignment = Alignment.Center,
                        ) { Icon(painterResource(R.drawable.ic_attach), contentDescription = null, tint = Gold) }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(m.fileName, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(Formatter.formatShortFileSize(ctx, m.size), color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
            m.text?.let { Text(it, fontSize = 15.sp, lineHeight = 21.sp) }
            Text(
                statusLine(m),
                color = if (m.status == "failed") MaterialTheme.colorScheme.error else TextMuted,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
            )
        }
    }
}

@Composable
fun Thumb(uri: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.loadThumbnail(Uri.parse(uri), android.util.Size(720, 720), null).asImageBitmap()
            }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            b, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.width(240.dp).height(240.dp * b.height / b.width.coerceAtLeast(1))
                .clip(RoundedCornerShape(12.dp)),
        )
        Spacer(Modifier.height(4.dp))
    } else {
        Box(
            Modifier.width(240.dp).height(160.dp).clip(RoundedCornerShape(12.dp)).background(Night.copy(alpha = 0.4f)),
        )
    }
}

fun statusLine(m: Msg): String {
    val t = SimpleDateFormat("HH:mm", TR).format(Date(m.time))
    return t + when (m.status) {
        "sending" -> "  ·  gönderiliyor"
        "failed" -> "  ·  gönderilemedi, tekrar dene"
        else -> if (m.mine) "  ✓" else ""
    }
}

fun openFile(ctx: Context, m: Msg) {
    val uri = m.fileUri ?: return
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), m.mime ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "Bu dosyayı açacak bir uygulama bulunamadı", Toast.LENGTH_SHORT).show()
    }
}

fun isIgnoringBattery(ctx: Context): Boolean =
    ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

@SuppressLint("BatteryLife")
fun requestBattery(ctx: Context) {
    runCatching {
        ctx.startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
        )
    }
}
